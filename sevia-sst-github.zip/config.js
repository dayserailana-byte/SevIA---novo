// Dados públicos do projeto Supabase (chave "anon" é pública; a service_role NUNCA vai aqui).
window.SEVIA_CONFIG = {
  url: "https://kxhrzaehsvijsokhtwac.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt4aHJ6YWVoc3ZpanNva2h0d2FjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTEwNTEzNTgsImV4cCI6MjEwNjYyNzM1OH0.Qe_ow06vqQ6Xr221KonE6yOPGqQkOFQkkqWGKmr5vIQ"
};
