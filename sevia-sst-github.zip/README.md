# SevIA SST 4.0

Sistema de campo para Segurança do Trabalho: relatório fotográfico, inspeção de segurança, plano de ação e relatórios em PDF, Word e Excel.

## Arquivos do site (raiz do repositório)
- `login.html` – entrada (usuário + senha; troca da senha provisória no primeiro acesso)
- `index.html` – o sistema
- `sevia-supabase.js` – liga o sistema ao Supabase
- `config.js` – URL e chave pública (anon) do projeto Supabase

## Pasta `supabase/`
- `01-schema.sql` – tabelas, regras de acesso (RLS) e bucket de fotos
- `functions/admin-usuarios` e `functions/ia` – Edge Functions (já publicadas no projeto)

## Segurança
Não coloque neste repositório: chave `service_role`, senha do banco ou a chave da API da Anthropic. A chave `anon` em `config.js` é pública por desenho; quem protege os dados é o login e as regras do banco.

## Publicação
Settings > Pages > Deploy from a branch > `main` / `(root)`. Endereço: `/login.html`.
