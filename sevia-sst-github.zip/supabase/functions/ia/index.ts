// Edge Function: ia
// Recebe {prompt, images:[{media_type,data}], json} e pergunta ao Claude (API da Anthropic).
// A chave fica só aqui no servidor:  supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
// Modelo (opcional):                  supabase secrets set ANTHROPIC_MODEL=claude-sonnet-5-5
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*", // troque pelo seu domínio ao publicar
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const quem = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const { data: u } = await quem.auth.getUser();
    if (!u?.user) return json({ erro: "Não autenticado." }, 401);
    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: eu } = await admin.from("sevia_perfis").select("perfil,ativo").eq("id", u.user.id).single();
    if (!eu || !eu.ativo || !["Administradora", "Técnico ADM", "Técnico SST"].includes(eu.perfil))
      return json({ erro: "Sem permissão para usar a IA." }, 403);

    const key = Deno.env.get("ANTHROPIC_API_KEY");
    if (!key) return json({ erro: "Chave da IA não configurada no servidor." }, 500);

    const { prompt, images = [], json: queJson } = await req.json();
    if (typeof prompt !== "string" || !prompt.trim()) return json({ erro: "Pergunta vazia." }, 400);
    if (!Array.isArray(images) || images.length > 8) return json({ erro: "Envie no máximo 8 fotos por vez." }, 400);

    const content: unknown[] = images.map((i: { media_type: string; data: string }) => ({
      type: "image",
      source: { type: "base64", media_type: i.media_type || "image/jpeg", data: i.data },
    }));
    content.push({ type: "text", text: queJson ? prompt + "\n\nResponda somente com JSON válido." : prompt });

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({
        model: Deno.env.get("ANTHROPIC_MODEL") ?? "claude-sonnet-5-5",
        max_tokens: 4096,
        messages: [{ role: "user", content }],
      }),
    });
    const d = await r.json();
    if (!r.ok) return json({ erro: d?.error?.message ?? "Falha na IA." }, 502);
    const text = (d.content ?? []).filter((c: { type: string }) => c.type === "text").map((c: { text: string }) => c.text).join("\n");
    return json({ text });
  } catch (e) {
    return json({ erro: String(e) }, 500);
  }
});
