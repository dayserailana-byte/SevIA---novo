// Edge Function: admin-usuarios
// Cria/reseta/desativa/exclui usuários. Só a Administradora pode chamar.
// A senha provisória é gerada AQUI (servidor) e devolvida uma única vez.
// Variáveis (já existem no Supabase): SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*", // troque pelo seu domínio ao publicar
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

// O Supabase exige e-mail; o login interno é  usuario@DOMINIO  (não precisa existir de verdade).
const DOMINIO = "login.sevia.interno";

const slug = (t: string) =>
  t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");

async function usuarioUnico(admin: any, nome: string): Promise<string> {
  const p = nome.trim().split(/\s+/).filter(Boolean);
  const base = p.length > 1 ? `${slug(p[0])}.${slug(p[p.length - 1])}` : slug(p[0] ?? "");
  let u = base, n = 2;
  while (true) {
    const { data } = await admin.from("sevia_perfis").select("id").eq("usuario", u).maybeSingle();
    if (!data) return u;
    u = base + n++;
  }
}

function senhaProvisoria(): string {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
  const b = new Uint32Array(12);
  crypto.getRandomValues(b);
  return Array.from(b, (n) => A[n % A.length]).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const quem = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const { data: u } = await quem.auth.getUser();
    if (!u?.user) return json({ erro: "Não autenticado." }, 401);
    const { data: eu } = await admin.from("sevia_perfis").select("perfil,ativo").eq("id", u.user.id).single();
    if (!eu || !eu.ativo || !["Administradora", "Técnico ADM"].includes(eu.perfil)) return json({ erro: "Somente a administradora." }, 403);

    const p = await req.json();
    if (p.acao === "criar") {
      const nome = String(p.nome ?? "").trim();
      if (slug(nome).length < 2) return json({ erro: "Informe o nome completo." }, 400);
      const contato = String(p.email ?? "").trim().toLowerCase(); // opcional
      const usuario = await usuarioUnico(admin, nome);
      const email = `${usuario}@${DOMINIO}`;
      if (!["Administradora", "Técnico ADM", "Técnico SST", "Cliente"].includes(p.perfil)) return json({ erro: "Perfil inválido." }, 400);
      if (p.perfil === "Cliente" && !p.empresa_id) return json({ erro: "Cliente precisa de empresa." }, 400);
      const senha = senhaProvisoria();
      const { data, error } = await admin.auth.admin.createUser({ email, password: senha, email_confirm: true });
      if (error) return json({ erro: error.message }, 400);
      const { error: e2 } = await admin.from("sevia_perfis").insert({
        id: data.user.id, nome, usuario, email: contato, telefone: p.telefone ?? "", perfil: p.perfil,
        empresa_id: p.perfil === "Cliente" ? p.empresa_id : null, trocar_senha: true,
      });
      if (e2) { await admin.auth.admin.deleteUser(data.user.id); return json({ erro: e2.message }, 400); }
      return json({ ok: true, id: data.user.id, usuario, senha_provisoria: senha });
    }
    if (p.acao === "resetar") {
      const senha = senhaProvisoria();
      const { error } = await admin.auth.admin.updateUserById(p.id, { password: senha });
      if (error) return json({ erro: error.message }, 400);
      await admin.from("sevia_perfis").update({ trocar_senha: true }).eq("id", p.id);
      return json({ ok: true, senha_provisoria: senha });
    }
    if (p.acao === "atualizar") {
      if (!["Administradora", "Técnico ADM", "Técnico SST", "Cliente"].includes(p.perfil)) return json({ erro: "Perfil inválido." }, 400);
      if (p.perfil === "Cliente" && !p.empresa_id) return json({ erro: "Cliente precisa de empresa." }, 400);
      if (p.id === u.user.id && (!["Administradora", "Técnico ADM"].includes(p.perfil) || p.ativo === false))
        return json({ erro: "Você não pode rebaixar nem desativar a si mesma." }, 400);
      const ativo = p.ativo !== false;
      const { error } = await admin.from("sevia_perfis").update({
        nome: p.nome, email: String(p.email ?? "").trim().toLowerCase(), telefone: p.telefone ?? "",
        perfil: p.perfil, empresa_id: p.perfil === "Cliente" ? p.empresa_id : null, ativo,
      }).eq("id", p.id);
      if (error) return json({ erro: error.message }, 400);
      await admin.auth.admin.updateUserById(p.id, { ban_duration: ativo ? "none" : "876000h" });
      return json({ ok: true });
    }
    if (p.acao === "ativar" || p.acao === "desativar") {
      const ativo = p.acao === "ativar";
      await admin.from("sevia_perfis").update({ ativo }).eq("id", p.id);
      await admin.auth.admin.updateUserById(p.id, { ban_duration: ativo ? "none" : "876000h" });
      return json({ ok: true });
    }
    if (p.acao === "excluir") {
      if (p.id === u.user.id) return json({ erro: "Você não pode excluir a si mesma." }, 400);
      const { error } = await admin.auth.admin.deleteUser(p.id);
      return json(error ? { erro: error.message } : { ok: true }, error ? 400 : 200);
    }
    return json({ erro: "Ação desconhecida." }, 400);
  } catch (e) {
    return json({ erro: String(e) }, 500);
  }
});
