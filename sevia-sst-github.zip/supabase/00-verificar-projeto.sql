-- SOMENTE LEITURA: não altera nada. Rode no SQL Editor do projeto e me mande o resultado.
select 'tabelas_public' as item, string_agg(table_name, ', ' order by table_name) as valor
  from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE'
union all
select 'tabelas_sevia_ja_existentes', coalesce(string_agg(table_name, ', '), '(nenhuma — ok)')
  from information_schema.tables where table_schema = 'public' and table_name like 'sevia\_%' escape '\'
union all
select 'usuarios_no_login', count(*)::text from auth.users
union all
select 'buckets_de_fotos', coalesce(string_agg(id, ', '), '(nenhum)') from storage.buckets;
