-- ============================================================================
-- SevIA SST 4.0 — banco, perfis, regras de acesso e fotos (Supabase)
-- Rode UMA vez no SQL Editor do projeto. Não contém senhas nem chaves.
-- ============================================================================

-- 1) PERFIS (um por usuário do login) ----------------------------------------
create table if not exists public.sevia_perfis (
  id            uuid primary key references auth.users(id) on delete cascade,
  nome          text not null,
  usuario       text not null unique,            -- login: primeiro.ultimo (ex.: maria.silva)
  email         text default '',                 -- e-mail de contato (opcional)
  telefone      text default '',
  perfil        text not null check (perfil in ('Administradora','Técnico ADM','Técnico SST','Cliente')),
  empresa_id    text,                            -- obrigatório para Cliente
  ativo         boolean not null default true,
  trocar_senha  boolean not null default true,   -- true = precisa trocar a senha provisória
  criado_em     timestamptz not null default now(),
  constraint sevia_cliente_tem_empresa check (perfil <> 'Cliente' or empresa_id is not null)
);
alter table public.sevia_perfis enable row level security;

create or replace function public.sevia_meu_perfil() returns text
language sql stable security definer set search_path = public as
$$ select perfil from public.sevia_perfis where id = auth.uid() and ativo $$;

create or replace function public.sevia_minha_empresa() returns text
language sql stable security definer set search_path = public as
$$ select empresa_id from public.sevia_perfis where id = auth.uid() and ativo $$;

drop policy if exists sevia_perfis_ler_proprio on public.sevia_perfis;
create policy sevia_perfis_ler_proprio on public.sevia_perfis for select using (id = auth.uid());
drop policy if exists sevia_perfis_admin_tudo on public.sevia_perfis;
create policy sevia_perfis_admin_tudo on public.sevia_perfis for all
  using (public.sevia_meu_perfil() in ('Administradora','Técnico ADM'))
  with check (public.sevia_meu_perfil() in ('Administradora','Técnico ADM'));

create or replace function public.sevia_concluir_troca_senha() returns void
language sql security definer set search_path = public as
$$ update public.sevia_perfis set trocar_senha = false where id = auth.uid() $$;
revoke all on function public.sevia_concluir_troca_senha() from public;
grant execute on function public.sevia_concluir_troca_senha() to authenticated;

-- 2) DOCUMENTOS (empresas, contratos, inspeções, não conformidades, ações, listas) ----
create table if not exists public.sevia_documentos (
  path          text primary key,                -- ex.: inspecoes/<id>
  colecao       text not null,                   -- ex.: inspecoes
  dados         jsonb not null,
  atualizado_em timestamptz not null default now()
);
create index if not exists sevia_documentos_colecao on public.sevia_documentos (colecao);
alter table public.sevia_documentos enable row level security;

-- Cliente só lê o que pertence à empresa dele.
create or replace function public.sevia_pode_ler(p text, c text, d jsonb) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare pf text := public.sevia_meu_perfil(); emp text := public.sevia_minha_empresa();
begin
  if pf in ('Administradora','Técnico ADM','Técnico SST') then return true; end if;
  if pf is distinct from 'Cliente' or emp is null then return false; end if;
  if c = 'empresas'   then return split_part(p,'/',2) = emp; end if;
  if c in ('contratos','inspecoes') then return d->>'empresaId' = emp; end if;
  if c = 'ncs' then
    return exists (select 1 from public.sevia_documentos i
      where i.path = 'inspecoes/' || (d->>'inspId') and i.dados->>'empresaId' = emp);
  end if;
  if c = 'acoes' then
    return exists (select 1 from public.sevia_documentos n join public.sevia_documentos i
        on i.path = 'inspecoes/' || (n.dados->>'inspId')
      where n.path = 'ncs/' || (d->>'ncId') and i.dados->>'empresaId' = emp);
  end if;
  if c = 'config' then return p in ('config/marca','config/cadastros'); end if;
  return false;
end $$;

drop policy if exists sevia_doc_ler on public.sevia_documentos;
create policy sevia_doc_ler on public.sevia_documentos for select using (public.sevia_pode_ler(path, colecao, dados));
drop policy if exists sevia_doc_escrever on public.sevia_documentos;
create policy sevia_doc_escrever on public.sevia_documentos for all
  using (public.sevia_meu_perfil() in ('Administradora','Técnico ADM','Técnico SST'))
  with check (public.sevia_meu_perfil() in ('Administradora','Técnico ADM','Técnico SST'));

-- atualização em tempo real
do $$ begin
  begin alter publication supabase_realtime add table public.sevia_documentos; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.sevia_perfis; exception when duplicate_object then null; end;
end $$;

-- 3) FOTOS (Storage) -----------------------------------------------------------
-- Bucket público: os nomes dos arquivos são códigos aleatórios impossíveis de adivinhar.
insert into storage.buckets (id, name, public) values ('sevia-fotos','sevia-fotos',true)
  on conflict (id) do nothing;
drop policy if exists sevia_fotos_enviar on storage.objects;
create policy sevia_fotos_enviar on storage.objects for insert to authenticated
  with check (bucket_id = 'sevia-fotos' and public.sevia_meu_perfil() in ('Administradora','Técnico ADM','Técnico SST'));
drop policy if exists sevia_fotos_apagar on storage.objects;
create policy sevia_fotos_apagar on storage.objects for delete to authenticated
  using (bucket_id = 'sevia-fotos' and public.sevia_meu_perfil() in ('Administradora','Técnico ADM'));

-- 4) PRIMEIRA ADMINISTRADORA ------------------------------------------------------
-- No painel: Authentication > Users > Add user > "Create new user", com
--   e-mail: dayse.railana@login.sevia.interno   e uma senha forte, marcando "Auto Confirm User".
-- Depois rode o comando abaixo (tire o "--" do começo das duas linhas):
-- insert into public.sevia_perfis (id, nome, usuario, perfil, trocar_senha)
-- select id, 'Dayse Railana', 'dayse.railana', 'Administradora', false
--   from auth.users where email = 'dayse.railana@login.sevia.interno';
